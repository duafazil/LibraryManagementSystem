/**
 * 
 */
/**
 * 
 */
module library {
	requires java.desktop;
}