/**
 * 
 */
/**
 * 
 */
module lmsproject {
	requires java.desktop;
}